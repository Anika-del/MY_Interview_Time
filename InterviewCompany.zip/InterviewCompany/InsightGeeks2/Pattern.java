package InterviewCompany.3InsightGeeks2;

public class Pattern {
    
}
